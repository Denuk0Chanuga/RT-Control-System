# serial_comms.py

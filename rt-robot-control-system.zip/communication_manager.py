# communication_manager.py

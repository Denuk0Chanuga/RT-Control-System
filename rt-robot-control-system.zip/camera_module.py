# camera_module.py
